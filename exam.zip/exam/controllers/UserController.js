const express = require('express')

const router = express.Router();

const mysqlConnection = require('../connections');

//get all employees
router.get('/', (req, res) => {
    mysqlConnection.query(`
        SELECT 
        id,
        first_name,
        last_name
        FROM 
        users 
        where 
        deleted_at 
        IS 
        NULL`,
        (err, rows, fields) => {
        if (!err)
            res.send(rows)
        else
            res.send(err)
    })
})

//get specific employee based on id
router.get('/:id', (req, res) => {
    mysqlConnection.query(`
            SELECT 
            first_name,
            last_name,
            case when ${req.params.id} = user_id then 'me' else relationship end as relationship
            FROM 
            users 
            WHERE 
            id = ${req.params.id} 
            AND deleted_at IS NULL`,
        (err, rows, fields) => {
            res.send(rows)
        })
})

//get user details and relatives
router.get('/:id/:relationship', (req, res) => {
    mysqlConnection.query(`
            SELECT 
            first_name,
            last_name,
            case when ${req.params.id} = id then 'me' else relationship end as relationship_status
            FROM 
            users 
            WHERE (user_id = ${req.params.id} OR id = ${req.params.id})
            AND relationship = '${req.params.relationship}'
            AND deleted_at IS NULL`,
        (err, rows, fields) => {
            res.send(rows)
        })
})

//add user and relationship
router.post('/', (req, res) => {
    let errors = {}
    if(! req.body.first_name)
        errors.first_name = 'First Name is Required'
    if(! req.body.first_name)
        errors.last_name = 'Last Name is Required'
    if(! req.body.relationship)
        errors.relationship = 'Relationship is Required'

    let errorCount = Object.keys(errors).length

    if(errorCount > 0)
        res.send(errors)

    const query = `
        INSERT
        INTO
        users (
               first_name,
               last_name,
               relationship,
               user_id,
               created_at
       )
        VALUES (
                '${req.body.first_name}',
                '${req.body.last_name}',
                '${req.body.relationship}',
                '${req.body.user_id}',    
                now()
        )`

    mysqlConnection.query(query, (err, rows, fields) => {
        if(!err)
            res.send('User Added')
        else
            res.send(err)
    })
})


//delete specific employee based on id
router.delete('/:id', (req, res) => {
    mysqlConnection.query(`UPDATE users SET deleted_at = now() where id = ${req.params.id}`, (err, rows, fields) => {
        res.send('User Deleted')
    })
})

//update employee based on id
router.patch('/:id', (req, res) => {
    const query = `
        UPDATE 
        users 
        SET 
            first_name = '${req.body.first_name}', 
            last_name = '${req.body.last_name}', 
            relationship = '${req.body.relationship}', 
            user_id = '${req.body.user_id}' 
        WHERE id = ${req.params.id}
        `
    mysqlConnection.query(query, (err, rows, fields) => {
        if(!err)
            res.send('User Updated')
        else
            res.send(err)
    })
})

module.exports = router;

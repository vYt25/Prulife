const express = require('express')
const port = process.env.PORT || 5000
const bodyParser = require('body-parser')
const UserController = require('./controllers/UserController.js')

const app = express()
app.use(express.json())
app.use(bodyParser.urlencoded())

app.use('/api/users', UserController)

app.listen(port, function () {
    console.log('listening to port ' + port);
})
